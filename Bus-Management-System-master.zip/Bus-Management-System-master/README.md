# Bus-Management-System
This is a mini project made by me and my team during my 3rd Semester in JAVA.
All the features are hardcoded by me and my team mates.

Project will be updated with new features as I get time..

Softwares Used:-
Java 8,JDBC,
MS Access,
Windows OS

Peace... :)
